const api = globalThis.browser ?? globalThis.chrome;
const DEFAULTS = { enabled: true, minSizeKB: 0, skipExt: "", videoButton: true };
(async () => {
  const s = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
  const en = document.getElementById("enabled");
  const min = document.getElementById("minSizeKB");
  const skip = document.getElementById("skipExt");
  en.checked = s.enabled;
  min.value = s.minSizeKB;
  skip.value = s.skipExt;
  en.onchange = () => api.storage.local.set({ enabled: en.checked });
  const vb = document.getElementById("videoButton");
  vb.checked = s.videoButton;
  vb.onchange = () => {
    api.storage.local.set({ videoButton: vb.checked });
    api.runtime.sendMessage({ type: "set-popup", on: vb.checked });
  };
  api.runtime.sendMessage({ type: "sync-popup", force: true }).then(async () => {
    vb.checked = (await api.storage.local.get({ videoButton: true })).videoButton;
  }).catch(() => {});
  min.onchange = () => api.storage.local.set({ minSizeKB: Math.max(0, +min.value || 0) });
  skip.onchange = () => api.storage.local.set({ skipExt: skip.value });
  const grab = document.getElementById("grab");
  grab.onclick = async () => {
    const [tab] = await api.tabs.query({ active: true, currentWindow: true });
    if (!tab || !/^https?:/i.test(tab.url || "")) { grab.textContent = "Open a video page first"; return; }
    grab.textContent = "Sending…";
    const r = await api.runtime.sendMessage({ type: "page-media", url: tab.url });
    grab.textContent = r && r.ok ? "Sent to Fast Download Manager" : "App not reachable";
    if (r && r.ok) setTimeout(() => window.close(), 700);
  };
  document.getElementById("open").onclick = () => { api.runtime.sendMessage("show"); window.close(); };
  const r = await api.runtime.sendMessage("ping");
  document.getElementById("status").textContent = r && r.ok
    ? `Connected · app ${r.version}`
    : "App not reachable. In the app open Settings › Browser › Connect.";
})();
