// Fast Download Manager browser integration.
// Captures browser downloads (and offers a context-menu entry) and hands them
// to the desktop app through the native-messaging host.
const api = globalThis.browser ?? globalThis.chrome;
const HOST = "app.fastdownloadmanager.host";

const DEFAULTS = { enabled: true, minSizeKB: 0, skipExt: "" };
async function settings() {
  return { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
}

async function cookieHeader(url) {
  try {
    const list = await api.cookies.getAll({ url });
    return list.map(c => `${c.name}=${c.value}`).join("; ") || undefined;
  } catch { return undefined; }
}

async function send(url, extra = {}) {
  const msg = {
    type: "add",
    url,
    media: !!extra.media,
    referrer: extra.referrer || undefined,
    filename: extra.filename || undefined,
    cookies: await cookieHeader(url),
    userAgent: navigator.userAgent,
  };
  try {
    const reply = await api.runtime.sendNativeMessage(HOST, msg);
    return !!(reply && reply.ok);
  } catch (e) {
    console.warn("FDM: native host unavailable", e);
    return false;
  }
}

function baseName(p) {
  return (p || "").split(/[\\/]/).pop();
}

// Ids we already handled, so cancelling doesn't loop.
const handled = new Set();

api.downloads.onCreated.addListener(async (item) => {
  const s = await settings();
  if (!s.enabled || handled.has(item.id)) return;
  const url = item.finalUrl || item.url;
  if (!/^https?:/i.test(url)) return; // blob:, data:, file: stay in the browser
  if (item.state && item.state !== "in_progress") return;
  if (s.minSizeKB > 0 && item.totalBytes > 0 && item.totalBytes < s.minSizeKB * 1024) return;
  const name = baseName(item.filename);
  const ext = (name.split(".").pop() || "").toLowerCase();
  if (s.skipExt && s.skipExt.split(/[\s,]+/).filter(Boolean).includes(ext)) return;
  handled.add(item.id);
  // Pause first so the browser doesn't race us while the app is contacted.
  try { await api.downloads.pause(item.id); } catch {}
  const ok = await send(url, { referrer: item.referrer, filename: name });
  if (ok) {
    try { await api.downloads.cancel(item.id); } catch {}
    try { await api.downloads.erase({ id: item.id }); } catch {}
  } else {
    // App unreachable: let the browser carry on as usual.
    try { await api.downloads.resume(item.id); } catch {}
  }
});

function setupMenus() {
  api.contextMenus.removeAll(() => {
    api.contextMenus.create({ id: "fdm-link", title: "Download with Fast Download Manager", contexts: ["link"] });
    api.contextMenus.create({ id: "fdm-media", title: "Download media with Fast Download Manager", contexts: ["video", "audio", "image"] });
    api.contextMenus.create({ id: "fdm-page", title: "Download video / audio from this page", contexts: ["page", "video", "audio"] });
  });
}
api.runtime.onInstalled.addListener(setupMenus);
if (api.runtime.onStartup) api.runtime.onStartup.addListener(setupMenus);

api.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "fdm-page") {
    const page = info.pageUrl || (tab && tab.url);
    if (page && /^https?:/i.test(page)) send(page, { media: true });
    return;
  }
  const url = info.menuItemId === "fdm-link" ? info.linkUrl : info.srcUrl;
  if (url && /^https?:/i.test(url)) send(url, { referrer: tab && tab.url });
});

// "Show Download video pop-up" lives in the app's Settings; mirror it here (and push
// changes made in the extension popup back). Rate-limited so pages don't spam the host.
let lastSync = 0;
async function syncPopup(force) {
  if (!force && Date.now() - lastSync < 20000) return;
  lastSync = Date.now();
  try {
    const r = await api.runtime.sendNativeMessage(HOST, { type: "settings" });
    if (r && r.ok && typeof r.videoPopup === "boolean") {
      const cur = (await api.storage.local.get({ videoButton: true })).videoButton;
      if (cur !== r.videoPopup) await api.storage.local.set({ videoButton: r.videoPopup });
    }
  } catch {}
}

// The popup asks whether the host answers, or asks to show the app.
api.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg === "ping") {
    api.runtime.sendNativeMessage(HOST, { type: "ping" })
      .then(r => reply({ ok: !!(r && r.ok), version: r && r.version }))
      .catch(e => reply({ ok: false, error: String(e) }));
    return true;
  }
  if (msg && msg.type === "sync-popup") {
    syncPopup(!!msg.force).then(() => reply({ ok: true }));
    return true;
  }
  if (msg && msg.type === "set-popup") {
    lastSync = Date.now();
    api.runtime.sendNativeMessage(HOST, { type: "setpopup", on: !!msg.on }).catch(() => {});
    return false;
  }
  if (msg && msg.type === "add-url") {
    send(msg.url, { referrer: msg.referrer }).then(ok => reply({ ok }));
    return true;
  }
  if (msg && msg.type === "page-media") {
    send(msg.url, { media: true }).then(ok => reply({ ok }));
    return true;
  }
  if (msg === "show") {
    api.runtime.sendNativeMessage(HOST, { type: "show" }).catch(() => {});
  }
  return false;
});
