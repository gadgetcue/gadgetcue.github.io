// Fast Download Manager: on-page video download buttons.
//  * A floating "Download video" pill over every playing/visible video (IDM-style pop-up).
//  * On YouTube: a "Download" button next to Share, and one at the top of the Share panel.
// Everything is controlled by the "Show download button on videos" option.
(() => {
  if (window.__fdmContent) return;
  window.__fdmContent = true;
  const api = globalThis.browser ?? globalThis.chrome;
  let enabled = true;

  const ICON =
    '<svg viewBox="0 0 24 24" width="12" height="12" aria-hidden="true"><path d="M12 3v11m0 0-4.5-4.5M12 14l4.5-4.5M5 20h14" ' +
    'fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  const css = `
  .fdm-pill{position:absolute;z-index:2147483646;display:flex;align-items:center;gap:4px;padding:3px 8px 3px 6px;
    border-radius:999px;border:1px solid rgba(255,255,255,.28);background:rgba(28,28,30,.62);color:#fff;
    font:600 11px/1.1 -apple-system,BlinkMacSystemFont,"Segoe UI",Inter,system-ui,sans-serif;letter-spacing:.1px;
    backdrop-filter:blur(18px) saturate(1.6);-webkit-backdrop-filter:blur(18px) saturate(1.6);
    box-shadow:0 3px 12px rgba(0,0,0,.28);cursor:pointer;opacity:0;transform:translateY(-4px);
    transition:opacity .18s ease,transform .18s ease,background .15s ease;pointer-events:auto;user-select:none}
  .fdm-pill.fdm-show{opacity:1;transform:none}
  .fdm-pill:hover{background:rgba(10,132,255,.88)}
  .fdm-pill .fdm-x{margin-left:2px;opacity:.7;font-weight:400;padding:0 2px}
  .fdm-pill .fdm-x:hover{opacity:1}
  .fdm-yt-btn{display:inline-flex;align-items:center;gap:6px;height:36px;padding:0 16px;margin-left:8px;border:0;
    border-radius:18px;background:#0a84ff;color:#fff;font:500 14px/36px Roboto,Arial,sans-serif;cursor:pointer}
  .fdm-yt-btn:hover{background:#0070e0}
  .fdm-share-target{display:inline-flex;flex-direction:column;align-items:center;flex:none;width:76px;margin:0 4px;padding:0;
    border:0;background:none;color:#0f0f0f;cursor:pointer;font:400 13px/18px Roboto,Arial,sans-serif}
  html[dark] .fdm-share-target{color:#f1f1f1}
  .fdm-share-target .fdm-circle{display:grid;place-items:center;width:60px;height:60px;border-radius:50%;margin-bottom:14px;
    background:linear-gradient(180deg,#3aa0ff,#0a6cff);color:#fff;box-shadow:inset 0 1px 0 rgba(255,255,255,.35)}
  .fdm-share-target:hover .fdm-circle{filter:brightness(1.08)}
  .fdm-share-target .fdm-label{white-space:nowrap}
  `;
  const style = document.createElement("style");
  style.textContent = css;
  (document.head || document.documentElement).appendChild(style);

  const isYouTube = /(^|\.)youtube\.com$/.test(location.hostname);

  function pageUrl() {
    // YouTube embeds and Shorts are fine for the video engine; strip playlist noise.
    try {
      const u = new URL(location.href);
      if (isYouTube && u.pathname === "/watch") {
        const v = u.searchParams.get("v");
        if (v) return `https://www.youtube.com/watch?v=${v}`;
      }
      return u.href;
    } catch {
      return location.href;
    }
  }

  function flash(el, text) {
    const label = el.querySelector(".fdm-label");
    if (!label) return;
    const old = label.textContent;
    label.textContent = text;
    setTimeout(() => (label.textContent = old), 1600);
  }

  async function sendVideo(video, el) {
    // Direct files (…/clip.mp4) go to the normal engine; streams and players to the video engine.
    const src = video && (video.currentSrc || video.src);
    let msg;
    if (src && /^https?:/i.test(src) && /\.(mp4|webm|mkv|mov|m4v|mp3|m4a|ogg)(\?|$)/i.test(src) && !isYouTube) {
      msg = { type: "add-url", url: src, referrer: location.href };
    } else {
      msg = { type: "page-media", url: pageUrl() };
    }
    try {
      const r = await api.runtime.sendMessage(msg);
      flash(el, r && r.ok ? "Sent ✓" : "App not reachable");
    } catch {
      flash(el, "App not reachable");
    }
  }

  // ---------------- floating pop-up over videos ----------------
  const pills = new Map(); // video -> pill
  const dismissed = new WeakSet();

  function placePill(video, pill) {
    const r = video.getBoundingClientRect();
    if (r.width < 200 || r.height < 120 || r.bottom < 0 || r.top > innerHeight) {
      pill.classList.remove("fdm-show");
      return;
    }
    pill.style.top = `${scrollY + r.top + 12}px`;
    pill.style.left = `${scrollX + r.right - pill.offsetWidth - 12}px`;
  }

  function attach(video) {
    if (pills.has(video) || dismissed.has(video)) return;
    const pill = document.createElement("div");
    pill.className = "fdm-pill";
    pill.innerHTML = `${ICON}<span class="fdm-label">Download video</span><span class="fdm-x" title="Hide">✕</span>`;
    pill.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.target.classList.contains("fdm-x")) {
        dismissed.add(video);
        pill.remove();
        pills.delete(video);
        return;
      }
      sendVideo(video, pill);
    }, true);
    document.body.appendChild(pill);
    pills.set(video, pill);
    let hideTimer = null;
    const show = () => {
      if (!enabled) return;
      clearTimeout(hideTimer);
      placePill(video, pill);
      pill.classList.add("fdm-show");
    };
    const hide = () => {
      hideTimer = setTimeout(() => pill.classList.remove("fdm-show"), 1800);
    };
    for (const t of [video, video.parentElement]) {
      if (!t) continue;
      t.addEventListener("mouseenter", show);
      t.addEventListener("mousemove", show);
      t.addEventListener("mouseleave", hide);
    }
    pill.addEventListener("mouseenter", show);
    pill.addEventListener("mouseleave", hide);
    video.addEventListener("play", () => { show(); hide(); });
  }

  function scanVideos() {
    if (!enabled) return;
    for (const v of document.querySelectorAll("video")) attach(v);
    for (const [v, p] of pills) {
      if (!document.contains(v)) {
        p.remove();
        pills.delete(v);
      } else if (p.classList.contains("fdm-show")) {
        placePill(v, p);
      }
    }
  }

  // ---------------- YouTube: next to Share, and in the Share panel ----------------
  function youtubeButtons() {
    if (!isYouTube || !enabled) return;
    // Watch page action bar
    const bar = document.querySelector("ytd-watch-metadata #top-level-buttons-computed");
    if (bar && !bar.querySelector(".fdm-yt-btn")) {
      const b = document.createElement("button");
      b.className = "fdm-yt-btn";
      b.innerHTML = `${ICON}<span class="fdm-label">Download</span>`;
      b.addEventListener("click", (e) => {
        e.preventDefault();
        sendVideo(null, b);
      });
      bar.appendChild(b);
    }
    // Share panel (opened by the Share button)
    const panel = document.querySelector("yt-unified-share-panel-renderer, ytd-unified-share-panel-renderer");
    if (panel && !panel.querySelector(".fdm-share-target")) {
      // A round target in the same row as Embed / WhatsApp / Facebook…, styled like them.
      const list = panel.querySelector("yt-third-party-share-target-section-renderer #contents");
      const first = list && list.querySelector("yt-share-target-renderer");
      if (list) {
        const t = document.createElement("button");
        t.className = "fdm-share-target";
        t.title = "Download with Fast Download Manager";
        t.innerHTML =
          `<span class="fdm-circle">${ICON.replace('width="16" height="16"', 'width="28" height="28"')}</span>` +
          `<span class="fdm-label">Download</span>`;
        t.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          sendVideo(null, t);
        });
        if (first) list.insertBefore(t, first);
        else list.prepend(t);
      }
    }
  }

  function removeAll() {
    for (const [, p] of pills) p.remove();
    pills.clear();
    document.querySelectorAll(".fdm-yt-btn, .fdm-share-target").forEach((n) => n.remove());
  }

  let pending = false;
  const tick = () => {
    pending = false;
    scanVideos();
    youtubeButtons();
  };
  new MutationObserver(() => {
    if (!pending) {
      pending = true;
      setTimeout(tick, 400);
    }
  }).observe(document.documentElement, { childList: true, subtree: true });
  addEventListener("scroll", () => { for (const [v, p] of pills) if (p.classList.contains("fdm-show")) placePill(v, p); }, { passive: true });
  addEventListener("resize", tick);

  // Ask the app for its "Show Download video pop-up" option (kept in sync with Settings).
  try { api.runtime.sendMessage({ type: "sync-popup" }); } catch {}
  api.storage.local.get({ videoButton: true }).then((s) => {
    enabled = s.videoButton !== false;
    tick();
  });
  api.storage.onChanged.addListener((ch) => {
    if (ch.videoButton) {
      enabled = ch.videoButton.newValue !== false;
      if (enabled) tick();
      else removeAll();
    }
  });
})();
